#include "depend.h"

int main()
{
    int a;
    cin>>a;
    square(a);
    return 0;
}
