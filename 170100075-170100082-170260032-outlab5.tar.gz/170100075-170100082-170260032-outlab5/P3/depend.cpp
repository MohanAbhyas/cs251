#include"depend.h"

int square(int x)
{
    cout<<"square of "<<x<<"is "<<x*x<<'\n';
    return x*x;
}
