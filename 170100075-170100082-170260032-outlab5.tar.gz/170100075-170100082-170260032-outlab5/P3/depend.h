#include<iostream>
using namespace std;

int square(int x);
//   kabali da
