#include <iostream>
#include <myengine.hpp>

using namespace std;

int main() {
    printf("%d\n", generateRandomNumber());
}
